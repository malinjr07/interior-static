Sequence of CSS/ Page Creation 

.home_page (Responsive)

.service_page (Responsive)

.portfolio (Responsive)

.faq (Responsive)

.blog (Responsive)

.blog_open

.our_location (Responsive)

.reseller (Responsive)

.affliate (Responsive)

.referral (Responsive)


/***Style.css is for 01-21 ***/

.pricing_1

.step-1

.Purchase-Step-1a

.Purchase-Step-2

.Purchase-Step-3

.step-4

.Purchase-Step-4a

.Purchase-Step-5

.Purchase-Step-6

.Purchase-Step-7( Reject)

.Placed


Delete these - 


slider
slick
critic_slider
comparsion
BeerSlider
atlantis.min

